﻿
class Nodo1
{
    public string valor;
    public Nodo izquierda;
    public Nodo derecha;

    public Nodo1(string valor)
    {
        this.valor = valor;
        this.izquierda = null;
        this.derecha = null;
    }
}
