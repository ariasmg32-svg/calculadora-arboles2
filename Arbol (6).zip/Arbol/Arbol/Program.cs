﻿
using System;

class Arbol
{
    static void Main(string[] args)
    {
        Console.Write("Primer numero: ");
        double numero1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Segundo numero: ");
        double numero2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Tercer numero: ");
        double numero3 = Convert.ToDouble(Console.ReadLine());

        Nodo primero = new Nodo(numero1.ToString());
        Nodo segundo = new Nodo(numero2.ToString());
        Nodo tercero = new Nodo(numero3.ToString());

        Nodo suma = new Nodo("+");
        suma.izquierda = primero;
        suma.derecha = segundo;

        Nodo raiz = new Nodo("*");
        raiz.izquierda = suma;
        raiz.derecha = tercero;

        Console.WriteLine("\nExpresion:");
        Console.WriteLine("(" + numero1 + " + " + numero2 + ") * " + numero3);

        Console.WriteLine("Resultado: " + Calcular(raiz));
    }

    static double Calcular(Nodo actual)
    {
        if (actual.izquierda == null && actual.derecha == null)
        {
            return Convert.ToDouble(actual.valor);
        }

        double izquierda = Calcular(actual.izquierda);
        double derecha = Calcular(actual.derecha);

        if (actual.valor == "+")
        {
            return izquierda + derecha;
        }

        return izquierda * derecha;
    }
}

class Nodo
{
    public string valor;
    public Nodo izquierda;
    public Nodo derecha;

    public Nodo(string valor)
    {
        this.valor = valor;
        izquierda = null;
        derecha = null;
    }
}
